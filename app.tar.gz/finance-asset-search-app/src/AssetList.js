import React, { useState, useMemo } from 'react';

// Dummy data
const dummyStocks = [
  { ticker: 'AAPL', name: 'Apple Inc.', price: 150.25, sector: 'Technology', volume: 1000000 },
  { ticker: 'GOOGL', name: 'Alphabet Inc.', price: 2750.80, sector: 'Technology', volume: 500000 },
  { ticker: 'MSFT', name: 'Microsoft Corporation', price: 305.50, sector: 'Technology', volume: 750000 },
  { ticker: 'AMZN', name: 'Amazon.com Inc.', price: 3380.00, sector: 'Consumer Cyclical', volume: 300000 },
  { ticker: 'FB', name: 'Meta Platforms Inc.', price: 330.75, sector: 'Communication Services', volume: 600000 },
  { ticker: 'TSLA', name: 'Tesla Inc.', price: 750.50, sector: 'Consumer Cyclical', volume: 400000 },
  { ticker: 'JPM', name: 'JPMorgan Chase & Co.', price: 160.40, sector: 'Financial Services', volume: 200000 },
  { ticker: 'V', name: 'Visa Inc.', price: 230.00, sector: 'Financial Services', volume: 150000 },
];

function AssetList() {
  const [searchTerm, setSearchTerm] = useState('');
  const [sortConfig, setSortConfig] = useState({ key: null, direction: 'ascending' });
  const [filters, setFilters] = useState({ sector: '' });

  // Sorting function
  const sortedStocks = useMemo(() => {
    let sortableStocks = [...dummyStocks];
    if (sortConfig.key !== null) {
      sortableStocks.sort((a, b) => {
        if (a[sortConfig.key] < b[sortConfig.key]) {
          return sortConfig.direction === 'ascending' ? -1 : 1;
        }
        if (a[sortConfig.key] > b[sortConfig.key]) {
          return sortConfig.direction === 'ascending' ? 1 : -1;
        }
        return 0;
      });
    }
    return sortableStocks;
  }, [sortConfig]); // dummyStocks is intentionally not included as it's static

  // Filtering and searching
  const filteredStocks = useMemo(() => {
    return sortedStocks.filter(stock => 
      (stock.ticker.toLowerCase().includes(searchTerm.toLowerCase()) ||
       stock.name.toLowerCase().includes(searchTerm.toLowerCase())) &&
      (filters.sector === '' || stock.sector === filters.sector)
    );
  }, [sortedStocks, searchTerm, filters]);

  const requestSort = (key) => {
    let direction = 'ascending';
    if (sortConfig.key === key && sortConfig.direction === 'ascending') {
      direction = 'descending';
    }
    setSortConfig({ key, direction });
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <h2 className="text-2xl font-bold mb-4">Asset List</h2>
      <div className="mb-4 flex flex-col sm:flex-row">
        <input
          type="text"
          placeholder="Search stocks..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="p-2 border rounded mb-2 sm:mb-0 sm:mr-2 flex-grow"
        />
        <select
          value={filters.sector}
          onChange={(e) => setFilters({ ...filters, sector: e.target.value })}
          className="p-2 border rounded"
        >
          <option value="">All Sectors</option>
          {[...new Set(dummyStocks.map(stock => stock.sector))].map(sector => (
            <option key={sector} value={sector}>{sector}</option>
          ))}
        </select>
      </div>
      <div className="overflow-x-auto">
        <table className="min-w-full bg-white">
          <thead className="bg-gray-100">
            <tr>
              {['ticker', 'name', 'price', 'sector', 'volume'].map((key) => (
                <th 
                  key={key}
                  onClick={() => requestSort(key)}
                  className="px-4 py-2 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider cursor-pointer"
                >
                  {key.charAt(0).toUpperCase() + key.slice(1)}
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {filteredStocks.map((stock) => (
              <tr key={stock.ticker} className="hover:bg-gray-50">
                <td className="px-4 py-2 whitespace-nowrap">{stock.ticker}</td>
                <td className="px-4 py-2 whitespace-nowrap">{stock.name}</td>
                <td className="px-4 py-2 whitespace-nowrap">${stock.price.toFixed(2)}</td>
                <td className="px-4 py-2 whitespace-nowrap">{stock.sector}</td>
                <td className="px-4 py-2 whitespace-nowrap">{stock.volume.toLocaleString()}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default AssetList;